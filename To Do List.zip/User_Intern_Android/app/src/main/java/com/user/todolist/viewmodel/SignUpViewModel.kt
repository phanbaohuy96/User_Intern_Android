package com.user.todolist.viewmodel

import androidx.lifecycle.ViewModel
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.GetTokenResult

class SignUpViewModel: ViewModel(){
    fun callAPI(task: Task<GetTokenResult>) {

    }
}